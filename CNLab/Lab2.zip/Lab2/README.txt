1. Documentation of diffrent network commands of linux
