1. Implement selective repeat protocol
