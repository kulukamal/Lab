1. Implement CRC
2. WireShark 
