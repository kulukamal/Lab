

1. implemented CRC for error detection
