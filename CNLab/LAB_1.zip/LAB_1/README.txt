1. Documentation of sveral question on computer networks
2. Program to implement file transfer between server and client using tcp/ip protocol

